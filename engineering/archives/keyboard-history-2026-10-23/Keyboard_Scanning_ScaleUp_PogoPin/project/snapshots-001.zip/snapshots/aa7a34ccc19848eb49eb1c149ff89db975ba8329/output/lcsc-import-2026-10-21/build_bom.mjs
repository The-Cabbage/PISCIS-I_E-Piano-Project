import fs from 'node:fs/promises';
import { Workbook } from '@oai/artifact-tool';

const dir = new URL('./', import.meta.url);
const source = JSON.parse(await fs.readFile(new URL('../passives-selection-2026-10-21/selection.json', dir), 'utf8'));
const rows = [['商品编号','数量','厂家型号','品牌','封装','规格','位号'], ...source.parts.map(p => [
  p.lcsc, p.quantity_per_board, p.mpn, p.manufacturer,
  p.footprint.includes('0805') ? '0805' : '0402',
  `${p.value} ${p.rating}`, p.designators.join(',')
])];
if (rows.length !== 10 || rows.slice(1).reduce((n,r) => n+r[1],0) !== 60) throw new Error('BOM count mismatch');
if (new Set(rows.slice(1).map(r=>r[0])).size !== 9) throw new Error('Duplicate product code');
const wb = Workbook.create();
const sheet = wb.worksheets.add('BOM');
sheet.getRange('A1:G10').values = rows;
sheet.showGridLines = false;
sheet.getRange('A1:G10').format.font = { name:'Arial', size:11 };
sheet.getRange('A1:G10').format.rowHeight = 30;
sheet.getRange('A1:G1').format = {fill:'#20374D',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'}};
sheet.getRange('A1:A10').format.columnWidth = 15;
sheet.getRange('B1:B10').format.columnWidth = 9;
sheet.getRange('C1:C10').format.columnWidth = 30;
sheet.getRange('D1:D10').format.columnWidth = 17;
sheet.getRange('E1:E10').format.columnWidth = 10;
sheet.getRange('F1:F10').format.columnWidth = 34;
sheet.getRange('G1:G10').format.columnWidth = 45;
sheet.getRange('B2:B10').setNumberFormat('0');
sheet.getRange('E2:E10').setNumberFormat('@');
wb.recalculate();
const output = sheet.getRange('A1:G10').values;
if (JSON.stringify(output) !== JSON.stringify(rows)) throw new Error('Worksheet values changed');
const q = x => /[",\r\n]/.test(String(x)) ? '"'+String(x).replaceAll('"','""')+'"' : String(x);
const csv = '\uFEFF'+output.map(r=>r.map(q).join(',')).join('\r\n')+'\r\n';
await fs.writeFile(new URL('LCSC_Passives_BOM_1Board.csv',dir),csv,'utf8');
const inspect = await wb.inspect({kind:'table',range:'BOM!A1:F10',include:'values',tableMaxRows:10,tableMaxCols:6,maxChars:4000});
await fs.writeFile(new URL('validation-inspect.ndjson',dir),inspect.ndjson);
const image = await wb.render({sheetName:'BOM',range:'A1:F10',scale:1,format:'png'});
await fs.writeFile(new URL('preview.png',dir),new Uint8Array(await image.arrayBuffer()));
console.log('Created 9-row UTF-8 BOM CSV, total quantity 60, one board; C20 excluded.');
