已加入工程 Keyboard_Private 私有库。符号的封装关联和 STEP 路径已改为私有库路径。配对及共享模型限制见 RESOURCE_NOTES_CN.md。
