# 嘉立创 PCB 制造文件

来源：项目中 2026-10-20 14:09 保存的 PISCIS-I_Keyboard.kicad_pcb。使用 KiCad 10.0.6 输出，源文件校验值见 source-sha256.json。

上传文件：PISCIS-I_Keyboard_JLCPCB_4L_1.2mm_2026-10-20.zip。

## 下单参数与层次

- 四层 FR-4，板厚 1.2 mm。
- 外形中心线尺寸约 82.6 × 72.6 mm；最终以 GM1 板框为准。KiCad job 文件的 82.8 × 72.8 mm 是包含 0.2 mm 板框线宽的边界估计，不应将线宽误作外形增量。
- 层顺序从顶到底：GTL=F.Cu，G1=In1.Cu，G2=In2.Cu，GBL=B.Cu。
- GTS/GBS 为双面阻焊开窗；GTO/GBO 为双面丝印；GM1 为板框及内部机械开孔。
- PTH.drl 为 276 个直径 0.3 mm 的金属化通孔；NPTH.drl 为 2 个直径 0.7 mm 的非金属化定位孔。
- 另外四个直径 2.5 mm 的安装孔在 Edge.Cuts 中，以闭合圆形铣孔轮廓输出到 GM1，因此不列入 Excellon 钻孔数量。上传预览应看到这四个机械开孔及两个连接器定位孔。
- 表面处理、阻焊颜色和数量在下单时选择；Gerber 本身不替代订单工艺参数。当前工程阻焊颜色设置为黑色；job 中 Finish=None 表示项目未指定表面处理。

ZIP 共 12 个文件，位于 ZIP 根目录：9 个 Gerber、2 个 Excellon、1 个 Gerber job。只包含裸板制造所需资料；SMT 装配或钢网还需单独准备 BOM、坐标和锡膏层。

## 导出和校验

先复制源 PCB，在独立制造副本中用 KiCad 原生 ZONE_FILLER 重新填充铜区，再输出 Gerber 与钻孔。原工程 PCB 没有被保存或修改。source-snapshot/ 保存原始和制造副本。

Gerber 使用 X2 属性、Protel 扩展名、毫米、4.6 坐标、绝对原点；Excellon 使用毫米、十进制坐标、绝对原点、PTH/NPTH 分离。丝印按阻焊开窗裁除。层次与原点设置参考嘉立创官方指南：https://jlcpcb.com/help/article/how-to-generate-gerber-and-drill-files-in-kicad-9 。

已检查：所有层及文件结束标记齐全，铜层顺序正确，job 引用文件存在，GM1 包含一个外轮廓及四个机械开孔闭合环，钻孔数量/单位/原点与板框坐标一致，ZIP 解压 CRC 检验通过。verification/export-validation.json 和 manufacturing-sha256.json 记录检查结果。

命令行 --check-zones 步骤发生与之前相同的异常；因此改用已完成原生铺铜的制造副本直接导出，导出命令成功。此处的格式及结构检查不等同整板 DRC/DFM 或独立 CAM 图形验收，上传后还需在嘉立创预览确认四层顺序、地平面、板框和孔位。

## 当前设计检查状态

制造副本中重新铺铜并遍历实际连接后，U2、U3、U7、U9、U19 的第五脚现均已与主地连通，见 verification/board-info.json。14:03 的历史 DRC 仍记录旧的五条未连接，不能直接认为导出版本仍有这些未连接。

D1 两数据焊盘间距 0.15 mm 对通用 0.2 mm 规则的例外仍需按推荐焊盘及板厂能力确认。本导出不改动该几何、不降低规则，也不代表整板 DRC 已通过。此前涉及真实五针连接器机械配合、霍尔灵敏度型号、C20 装配状态等事项仍以最新硬件审阅报告及实际确认结果为准。
