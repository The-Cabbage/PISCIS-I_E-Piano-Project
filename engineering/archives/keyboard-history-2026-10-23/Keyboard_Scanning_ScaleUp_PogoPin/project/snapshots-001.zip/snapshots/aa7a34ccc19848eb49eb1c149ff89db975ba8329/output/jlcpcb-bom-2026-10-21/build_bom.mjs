import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { Workbook } from '@oai/artifact-tool';

const dir = new URL('./', import.meta.url);
const inventory = JSON.parse(await fs.readFile(new URL('inventory-source.json', dir), 'utf8'));
const inv = Object.fromEntries(inventory.map(p => [p.productCode,p]));
const passive = JSON.parse(await fs.readFile(new URL('../passives-selection-2026-10-21/selection.json', dir), 'utf8')).parts;
const raw = await Workbook.fromCSV(await fs.readFile(new URL('source-bom.csv',dir),'utf8'), {sheetName:'Source'});
const sourceRows = raw.worksheets.getItemAt(0).getUsedRange().values.slice(1).filter(r=>r[0]);
const source = sourceRows.map(r=>({refs:String(r[0]).split(','), value:r[1], footprint:r[2], quantity:Number(r[3])}));
const footprintFor = ref => source.find(p=>p.refs.includes(ref)).footprint;
const parts = passive.map(p=>({...p, note:''}));
Object.assign(parts.find(p=>p.value==='100k'), {lcsc:'C2784785',mpn:'PS02W8F1003TCE',manufacturer:'UNI-ROYAL',rating:'±1% 125mW 50V',note:'替换缺货的 0402WGF1003TCE；阻值/精度/0402 封装相同'});
Object.assign(parts.find(p=>p.value==='33R'), {lcsc:'C138002',mpn:'RC0402FR-0733RL',manufacturer:'YAGEO',rating:'±1% 62.5mW 50V',note:'替换即时库存为 0 的 C25105；阻值/精度/0402 封装相同'});
function add(refs,value,code,rating,note=''){
  const i=inv[code];
  parts.push({designators:refs,quantity_per_board:refs.length,value,footprint:footprintFor(refs[0]),manufacturer:i.brandNameEn,mpn:i.productModel,lcsc:code,rating,note});
}
add(['D1'],'PESD3V3C2UM(ES)','C51223760','2-channel 3.3V 0.51pF DFN1006-3L','订单替换 SYT13S03SMD；1/2=IO、3=GND；按实物 1 脚核对贴装角度；新器件需验证 USB/ESD');
add(['D3','D4'],'SMF5.0A','C151296','5V unidirectional TVS SOD-123FL');
add(Array.from({length:36},(_,n)=>`U${n+1}`),'SC4102DN-TR','C42408042','DFN1616-6L; 1.5mV/G @3.3V','用户确认采用 SC4102；重新校准键程、触发阈值和测速；不得沿用 SC4103 的参数');
add(['U37'],'74HC4067BQ,118','C547033','DHVQFN24 SOT815-1; 3.5x5.5mm');
add(['U40'],'CH32X035G8U6','C7437027','WQFN28 4x4mm');
add(['U41'],'XC6210B332MR-G','C47719','3.3V 700mA SOT-25-5','-G 为兼容订货后缀；保持 B 型 CE 逻辑');
add(['U42'],'LP5308B6F','C5139783','SOT-23-6');

const refs = parts.flatMap(p=>p.designators);
assert.equal(parts.length,16);
assert.equal(refs.length,103);
assert.equal(new Set(refs).size,103);
assert.equal(new Set(parts.map(p=>p.lcsc)).size,16);
for(const p of parts){
  assert.equal(p.quantity_per_board,p.designators.length);
  assert.equal(inv[p.lcsc].productModel,p.mpn);
  assert.ok(inv[p.lcsc].domesticStockVO.shipImmediately>=p.quantity_per_board,`${p.lcsc}: no immediate stock`);
  assert.ok(p.designators.every(ref=>footprintFor(ref)===p.footprint));
}
const excluded = [
  {designators:['C20'],reason:'用户确认：本次订单暂不装；源原理图仍为 OPTION，本次没有修改设计文件'},
  {designators:['J2'],reason:'用户确认：自备手焊；自定义五针侧贴 Pogo，无已核实采购料号'},
  {designators:Array.from({length:8},(_,n)=>`TP${n+1}`),reason:'PCB 铜测试焊盘，无需采购或贴片'},
];
const all = [...refs,...excluded.flatMap(p=>p.designators)].sort();
assert.deepEqual(all,source.flatMap(p=>p.refs).sort());
assert.equal(all.length,113);

const shortPackage = p => p.footprint.includes('0402')?'0402':p.footprint.includes('0805')?'0805':inv[p.lcsc].encapStandard;
const mall = [['商品编号','数量','厂家型号','品牌','封装','规格','位号'],...parts.map(p=>[p.lcsc,p.quantity_per_board,p.mpn,p.manufacturer,shortPackage(p),`${p.value} ${p.rating}`,p.designators.join(',')])];
const smt = [['Comment','Designator','Footprint','Quantity','LCSC Part #','Manufacturer','Manufacturer Part'],...parts.map(p=>[`${p.value} ${p.rating}`,p.designators.join(','),p.footprint,p.quantity_per_board,p.lcsc,p.manufacturer,p.mpn])];
const wb = Workbook.create();
const files = [['LCSC_Complete_BOM_1Board.csv','商城采购',mall],['JLCPCB_SMT_BOM_1Board.csv','SMT导入',smt]];
const q = value => '"'+String(value??'').replaceAll('"','""')+'"';
for(const [file,name,rows] of files){
  const sheet=wb.worksheets.add(name);
  sheet.getRange(`A1:G${rows.length}`).values=rows;
  sheet.showGridLines=false;
  sheet.getRange(`A1:G${rows.length}`).format.font={name:'Arial',size:10};
  sheet.getRange(`A1:G${rows.length}`).format.rowHeight=30;
  sheet.getRange(`A1:G${rows.length}`).format.wrapText=true;
  sheet.getRange('A1:G1').format={fill:'#20374D',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'}};
  const widths=name==='商城采购'?[16,8,29,22,23,48,50]:[52,45,64,9,16,22,29];
  widths.forEach((width,i)=>sheet.getRangeByIndexes(0,i,rows.length,1).format.columnWidth=width);
  if(name==='商城采购'){
    sheet.getRange('E2:E10').setNumberFormat('0000');
    sheet.getRange('F11:F17').format.rowHeight=48;
  }else{
    sheet.getRange('A2:G2').format.rowHeight=95;
    sheet.getRange('A13:G13').format.rowHeight=80;
    sheet.getRange('A11:G11').format.rowHeight=50;
    sheet.getRange('A14:G15').format.rowHeight=50;
  }
}
wb.recalculate();
for(const [file,name,rows] of files){
  const actual=wb.worksheets.getItem(name).getRange(`A1:G${rows.length}`).values;
  assert.deepEqual(actual,rows);
  await fs.writeFile(new URL(file,dir),'\uFEFF'+actual.map(r=>r.map(q).join(',')).join('\r\n')+'\r\n');
}
const inspect=await wb.inspect({kind:'table',range:"'商城采购'!A1:F17",include:'values',tableMaxRows:17,tableMaxCols:6,maxChars:8000});
await fs.writeFile(new URL('validation-inspect.ndjson',dir),inspect.ndjson);
for(const [name,file] of [['商城采购','preview-mall.png'],['SMT导入','preview-smt.png']]){
  const preview=await wb.render({sheetName:name,range:name==='商城采购'?'A1:F17':'A1:E17',scale:1,format:'png'});
  await fs.writeFile(new URL(file,dir),new Uint8Array(await preview.arrayBuffer()));
}
await fs.writeFile(new URL('order-selection.json',dir),JSON.stringify({date:'2026-10-21',quantity_basis:'one board',parts,excluded,covered_designators:113,order_quantity:103,stock_scope:'LCSC public product page domesticStockVO.shipImmediately; not authenticated domestic SMT order inventory',source_design_modified:false},null,2));
const stockTable=parts.map(p=>`| ${p.designators.length>8?'U1–U36':p.designators.join('、')} | ${p.mpn} | ${p.lcsc} | ${p.quantity_per_board} | ${inv[p.lcsc].domesticStockVO.shipImmediately.toLocaleString('en-US')} | [商品页](${inv[p.lcsc].source_url}) |`).join('\n');
const note=`# 当前键盘扫描 PCB 下单说明\n\n日期：2026-10-21。根据本次保存工程重新导出 BOM，并按公开采购资料匹配物料。\n\n## 交付与数量\n\n- LCSC_Complete_BOM_1Board.csv：立创商城 BOM 配单用，商品编号/数量/厂家型号/品牌/封装/规格/位号；16 种物料、103 件/板。\n- JLCPCB_SMT_BOM_1Board.csv：嘉立创 SMT BOM 导入用，Comment/Designator/Footprint/Quantity/LCSC Part #/Manufacturer/Manufacturer Part。导入时对应匹配字段。\n- 均为 UTF-8 BOM、逗号分隔、CRLF，完整展开位号，逗号字段已引用。\n- 数量均为单板实际用量；SMT 板数在平台指定，商城采购需乘板数并按起购量、包装倍数和损耗调整。\n\n## 用户已确认的例外\n\nC20 本次订单暂不装；J2 自备手焊，不填写虚构采购码。TP1–TP8 为 PCB 铜焊盘，全部不采购、不贴装。\n\n核对：103 个采购位号 + C20 + J2 + 8 个测试焊盘 = 原始 BOM 全部 113 个位号；无漏项或重复。原理图和 PCB 未改动，C20 源文件仍为 OPTION，因此不能将旧版未经筛选的坐标直接作为本次装配坐标。\n\n## 现货核对\n\n下表来自公开 LCSC 商品页面内嵌商品数据的 domesticStockVO.shipImmediately 字段，每条带有实际查询 UTC 时间，原始记录见 inventory-source.json。仅采用即时库存大于单板用量的物料；C25105 即时库存为 0，已替换。此为公开采购库存快照，未登录国内商城或嘉立创 SMT 订单，没有锁定库存，不能保证所有物料在具体 SMT 订单均无需代购/订货。导入后只选择现货，若显示需订货应停在选料环节，不自动接受交期。\n\n| 位号 | 厂家型号 | 货号 | 单板数量 | 查询即时库存/颗 | 来源 |\n|---|---|---|---:|---:|---|\n${stockTable}\n\n## 本次订单选料变化\n\n1. R1、R12–R15：PS02W8F1003TCE / C2784785，100 kΩ、±1%、0402、125 mW、50 V，替换缺货的 0402WGF1003TCE。\n2. R2：RC0402FR-0733RL / C138002，33 Ω、±1%、0402、62.5 mW、50 V，替换当前即时库存为 0 的 C25105。\n3. U1–U36：用户确认采用 SC4102DN-TR / C42408042。与 SC410X 系列当前 DFN1616 封装和引脚配置匹配。在 3.3 V 下典型灵敏度为 1.5 mV/G，而 SC4103 为 2.5 mV/G；同磁场下信号幅度约为后者的 60%。必须重新校准键程、触发阈值、释放阈值和测速，并实测信噪比与全行程，不能仅换 BOM 后沿用旧参数。商城灵敏度字段可能采用不同供电条件，工程依据以原厂手册为准。\n4. U41：采用 XC6210B332MR-G / C47719，兼容原型号的 -G 环保后缀，保持 B 型 CE 逻辑。\n5. D1：订单选用 ElecSuper PESD3V3C2UM(ES) / C51223760，替换无法匹配立创货号的 SYT13S03SMD。已查阅厂家 Rev-1.2 手册：1/2=IO、3=GND；DFN1006-3L，IO 端子中心距 0.35 mm；3.3 V 工作、典型 0.51 pF、最大 0.60 pF、12 A 的 8/20 μs 脉冲下最大钳位 5 V。端子尺寸与当前焊盘有覆盖，可在现有焊盘上装配；厂家推荐焊盘不同，不声称两者推荐 land pattern 完全相同。原器件约 0.42 pF、TLP/触发曲线与新器件不同，需样板验证 USB 枚举、数据传输及 ESD。必须按实际器件 1 脚/底视图复核旋转，不能照搬相似型号的自动角度。\n\nD1 新器件数据手册：https://datasheet.lcsc.com/datasheet/pdf/3f770d8afbe2808a8f8a2582526fece5.pdf?productCode=C51223760 。\n霍尔原厂资料：https://www.semiment.com/UploadFiles/6720/SC4101_SC4102_SC4103_SC4104_CN.pdf 。\nXC6210 原厂资料：https://product.torexsemi.com/system/files/series/xc6210.pdf 。\nR2 原厂规格：https://www.yageogroup.com/component-documentation/download/specsheet/RC0402FR-0733RL 。\n\n## 导入与装配\n\n商城用采购版上传 BOM 智能云表，优先按商品编号精确匹配。SMT 用 SMT 版匹配位号、封装、数量和物料编号；按当前 BOM 筛选同版 CPL，仅保留 103 个采购位号，排除 C20、J2、TP1–TP8。当前交付不含新生成或校验过的 CPL，不能仅凭 CSV 直接投产。\n\n原项目私有封装名称保留在 SMT CSV，反映实际 PCB 焊盘。平台可能要求人工映射自定义封装；不要按名称模糊匹配为相似外壳。检查 U37 的 DHVQFN24，禁止换成 TSSOP；检查 36 颗霍尔和 U40 的 1 脚及裸焊盘。对 D1 当前 0.15 mm 焊盘间距等原设计制造条件，仍按最新审阅记录与工厂确认。\n\n当前文件用于选料与订单准备，不是新的投板放行，也不表示已上传、付款、锁库或提交生产。\n`;
await fs.writeFile(new URL('Order_Notes_CN.md',dir),note);
console.log(JSON.stringify({csv_files:files.map(x=>x[0]),sku_count:16,quantity_per_board:103,coverage:113,source_design_modified:false}));
