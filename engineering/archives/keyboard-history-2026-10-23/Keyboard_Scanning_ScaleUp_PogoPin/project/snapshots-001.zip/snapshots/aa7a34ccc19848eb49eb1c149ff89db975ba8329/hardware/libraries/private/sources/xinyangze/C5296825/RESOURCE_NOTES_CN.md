# 鑫扬泽四针侧贴连接器 KiCad 下载包

来源：**嘉立创EDA/EasyEDA官方库 / JLCEDA/EasyEDA Official Library**，https://easyeda.com/ 、https://lceda.cn/ 。原始响应及版权元数据保留在 sources。
下载日期：2026-10-19。使用 KiCad 10.0.6 原生导入器转换，未修改当前项目原理图、PCB、库表或私有库。

| 类型 | 型号 | 立创编号 |
|---|---|---|
| 弹簧公座 | YZ165615055F-04025-02 | C54799748 |
| 固定触点母座候选 | YZ199315035T-04025-01 | C5296825 |

## 内容与安装

- Xinyangze_4Pin.kicad_sym：两个独立型号的符号，针脚均设 passive。
- Xinyangze_4Pin.pretty：两个封装，保留下载库的焊盘和定位孔坐标。
- Xinyangze_4Pin.3dshapes：两个下载的 STEP。
- sources：各自原厂 PDF、图纸预览、商品页面和原始 EasyEDA JSON。

在 KiCad“管理符号库/管理封装库”中分别添加符号库与 .pretty 文件夹，库昵称均使用 Xinyangze_4Pin。符号已经关联对应封装。
当前目录中封装的模型路径按本项目位置配置。搬移或解压到其他项目时，请在封装属性的 3D 模型页重新选择 .3dshapes 中同名 STEP。

## 图纸核对与限制

两侧均为 4Pin、2.5 mm 针距，四个焊盘 1.6 × 2.3 mm；两个 Ø0.7 mm 非金属化定位孔，孔间距 10.5 mm。孔中心距焊盘后端 1.5 mm，换算到焊盘中心线 Y=-0.35 mm。
公座自由轴向长度 5.5 mm、工作轴向长度 4.0 mm；母座轴向长度 3.5 mm。它们沿触点轴线，不应理解为侧贴后的板上高度。两侧本体宽 11 mm，触点高度中心线与安装基准相符。
母座按原厂尺寸图的针距、安装和接触结构选为候选，未找到厂家明确指定配对的文档；不将相同针距直接视作配套认证。正式机械配合仍需样件或厂家确认。
两侧符号针号均对应各自封装同号焊盘。对接后针号可能镜像，实际板间连线须按装配朝向检查。

公座 -02 官方库链接的共享封装/STEP名称为 YZ165615055F-04025-01，已按 -02 图纸 D.0 (2025-02-20) 核对焊盘与定位孔。STEP 保留该共享库模型，只用于装配参考，不声明为原厂 -02 精密认证模型。模型原始导入偏移/旋转保持不变。
母座 STEP 来自其官方库关联模型，同样不是厂家认证文件。精确配合以随附图纸为准。

## 资源地址

- 公座：https://www.lcsc.com/product-detail/C54799748.html
- 母座：https://www.lcsc.com/product-detail/C5296825.html
- API：https://easyeda.com/api/products/C54799748/components?version=6.4.19.6
- API：https://easyeda.com/api/products/C5296825/components?version=6.4.19.6
- 公座 STEP：https://modules.easyeda.com/qAxj6KHrDKw4blvCG8QJPs7Y/0949b7f59efd4da4a1db7d6a6f35cbbe
- 母座 STEP：https://modules.easyeda.com/qAxj6KHrDKw4blvCG8QJPs7Y/46c7ad2f0955497d95a5b85be528c3f0

## 验证

两个符号及两个封装通过 KiCad 原生 SVG 导出；两个封装通过 pcbnew 原生读取，4 个编号焊盘及 2 个定位孔的尺寸断言通过。两个 STEP 被 KiCad STEP 导出器实际载入并导出为临时装配验证文件，路径可解析。验证夹具没有板外框，因此出现板框警告，与交付封装无关。
