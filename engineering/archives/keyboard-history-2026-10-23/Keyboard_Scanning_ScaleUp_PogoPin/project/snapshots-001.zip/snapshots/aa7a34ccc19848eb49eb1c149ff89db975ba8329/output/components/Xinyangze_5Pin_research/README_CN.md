# 鑫扬泽五针资源查询（尚未确认为配套）

下载日期：2026-10-19。

## 已下载的原厂图纸

- 母座候选 YZ92015035T-05025-02，C55111303，图纸 D.0，2024-05-05。五针，2.5 mm 间距；胶芯 12.8 × 2.5 × 2.2 mm，针件全长 3.5 mm。推荐五个直径 2.2 mm 的圆形焊盘。图纸不含磁铁，不是此前用户要求的侧贴结构。
- 公座候选 YZR0158-20050-05025-01，C55549969，图纸 A.1，2022-03-24。五针，2.5 mm 间距；带磁铁外壳，外轮廓宽 21.2 mm，主壳高度 6.86 mm；推荐五个直径 2.2 mm 的圆形焊盘。

两款仅触点数量、间距一致，不能据此确认公母机械配套。暂未导入项目私有库。

## 下载来源

- https://www.lcsc.com/product-detail/C55111303.html
- https://datasheet.lcsc.com/datasheet/pdf/ad721db74aea06d30a74cc44d8e1485d.pdf?productCode=C55111303
- https://www.lcsc.com/product-detail/C55549969.html
- https://datasheet.lcsc.com/datasheet/pdf/61c0b9976aa00a2b3e076adbfaf68d79.pdf?productCode=C55549969

## EDA 资源查询

两款 https://easyeda.com/api/products/{料号}/components?version=6.4.19.6 接口均返回 Component not found。
两款 /svgs 接口均返回 原理图未绘制。原始响应保留在对应目录中。
未找到可下载的公开原厂 STEP、符号或封装。不把自建资源标作原厂下载资源。

## 后续

用户已确认：优先侧贴，重新找公母配套型号。

追加核查：
- 官方侧贴连接器系列：https://xyzpogopin.com/page125?product_id=75 。页面文字列出侧帖式 2pin、3pin、4pin，未列出 5pin。页面快照保存为 manufacturer-side-mount-series.html。
- 官方固定触点系列：https://xyzpogopin.com/page125?product_id=76 。页面快照保存为 manufacturer-fixed-contact-series.html。
- 仍未核实到鑫扬泽五针侧贴成套公母料号、原厂配合图及公开 STEP/EDA 下载；此结论仅表示公开资料未找到，不代表厂家一定不生产。
- 不可通过把 03025 改为 05025 推定存在新料号，也不能将三针模型拉长当作五针原厂模型。

给厂家的询料文字（未发送）：
需要与 YZ10515055F/YZ126715035T 三针侧贴公母结构类似的 5Pin 成套公母座，优先 2.5 mm 针距，触点轴线平行 PCB，公母两端均需 PCB 侧贴安装。请提供完整公母料号、采购链接、带推荐焊盘及针号方向的尺寸图、配合后板间距与工作压缩行程，以及双方 STEP、符号和 PCB 封装。若没有现成五针型号，请说明是否需定制。
