# YZ10515055F-03025-01 KiCad 资源

嘉立创货号：C54799715。三针侧贴 Pogo Pin，针距 2.5 mm。

已加入当前项目的 `Keyboard_Private` 符号与封装库。KiCad 符号选择器中搜索 `YZ10515055F-03025-01` 即可；若列表尚未更新，关闭并重新打开选择器或编辑器。

- 符号：`Keyboard_Private:YZ10515055F-03025-01`
- 封装：`Keyboard_Private:PogoPin_Xinyangze_YZ10515055F-03025-01_1x03_P2.50mm_SideMount`
- 3 个贴片焊盘：1.6 × 2.3 mm，2.5 mm 间距。
- 2 个非金属化定位孔：Ø0.7 mm。
- 符号 1/2/3 对应封装 1/2/3，电气类型为 passive；实际供电或数据功能由设计者指定。

官方 C54799715 记录关联的共享封装名称为 `CONN-SMD_3P-P2.50_YZ10515055F-03025-02`。已按 -01 原厂图纸核对上述焊盘、针距及定位孔；采购型号始终为 -01。下载的原始数据和来源信息完整保留。

配套 STEP 为该共享库关联的参考模型，不作为原厂 -01 机械认证模型。精确外壳配合以随附 -01 PDF 图纸为准。

ZIP 中仅含此元件的独立符号库、封装、模型、原始数据及图纸。符号库文件名为 `Keyboard_Private.kicad_sym`；不要用独立库覆盖当前项目包含其他元件的同名库。当前项目已经完成追加，无需再次安装。

验证：KiCad 10.0.6 原生符号 SVG 导出通过；原生封装读取和 SVG 导出通过；3 个编号焊盘和 2 个定位孔的尺寸/坐标与下载源一致；已有符号内容保持不变；PCB、各原理图及库表的内容哈希未变化。

来源：**嘉立创EDA/EasyEDA官方库 / JLCEDA/EasyEDA Official Library**：https://lceda.cn/ 、https://easyeda.com/

商品：https://www.lcsc.com/product-detail/C54799715.html

完整追溯记录：`hardware/libraries/private/sources/xinyangze/C54799715/README.md`。
