# 当前键盘扫描 PCB 下单说明

日期：2026-10-21。根据本次保存工程重新导出 BOM，并按公开采购资料匹配物料。

## 交付与数量

- LCSC_Complete_BOM_1Board.csv：立创商城 BOM 配单用，商品编号/数量/厂家型号/品牌/封装/规格/位号；16 种物料、103 件/板。
- JLCPCB_SMT_BOM_1Board.csv：嘉立创 SMT BOM 导入用，Comment/Designator/Footprint/Quantity/LCSC Part #/Manufacturer/Manufacturer Part。导入时对应匹配字段。
- 均为 UTF-8 BOM、逗号分隔、CRLF，完整展开位号，逗号字段已引用。
- 数量均为单板实际用量；SMT 板数在平台指定，商城采购需乘板数并按起购量、包装倍数和损耗调整。

## 用户已确认的例外

C20 本次订单暂不装；J2 自备手焊，不填写虚构采购码。TP1–TP8 为 PCB 铜焊盘，全部不采购、不贴装。

核对：103 个采购位号 + C20 + J2 + 8 个测试焊盘 = 原始 BOM 全部 113 个位号；无漏项或重复。原理图和 PCB 未改动，C20 源文件仍为 OPTION，因此不能将旧版未经筛选的坐标直接作为本次装配坐标。

## 现货核对

下表来自公开 LCSC 商品页面内嵌商品数据的 domesticStockVO.shipImmediately 字段，每条带有实际查询 UTC 时间，原始记录见 inventory-source.json。仅采用即时库存大于单板用量的物料；C25105 即时库存为 0，已替换。此为公开采购库存快照，未登录国内商城或嘉立创 SMT 订单，没有锁定库存，不能保证所有物料在具体 SMT 订单均无需代购/订货。导入后只选择现货，若显示需订货应停在选料环节，不自动接受交期。

| 位号 | 厂家型号 | 货号 | 单板数量 | 查询即时库存/颗 | 来源 |
|---|---|---|---:|---:|---|
| U1–U36 | CL05B104KO5NNNC | C1525 | 40 | 10,512,000 | [商品页](https://www.lcsc.com/product-detail/C1525.html) |
| C2、C4、C5、C6 | CL05A105KA5NQNC | C52923 | 4 | 13,600 | [商品页](https://www.lcsc.com/product-detail/C52923.html) |
| C45 | GRM21BR71H105KA12L | C77083 | 1 | 15,490 | [商品页](https://www.lcsc.com/product-detail/C77083.html) |
| C51 | CL05A475KP5NRNC | C368809 | 1 | 1,277,850 | [商品页](https://www.lcsc.com/product-detail/C368809.html) |
| R1、R12、R13、R14、R15 | PS02W8F1003TCE | C2784785 | 5 | 18,900 | [商品页](https://www.lcsc.com/product-detail/C2784785.html) |
| R2 | RC0402FR-0733RL | C138002 | 1 | 6,525,600 | [商品页](https://www.lcsc.com/product-detail/C138002.html) |
| R8、R9、R10、R11 | 0402WGF470JTCE | C25118 | 4 | 1,502,600 | [商品页](https://www.lcsc.com/product-detail/C25118.html) |
| R16、R17、R18 | 0402WGF1002TCE | C25744 | 3 | 86,400 | [商品页](https://www.lcsc.com/product-detail/C25744.html) |
| R19 | 0402WGF7502TCE | C25798 | 1 | 391,900 | [商品页](https://www.lcsc.com/product-detail/C25798.html) |
| D1 | PESD3V3C2UM(ES) | C51223760 | 1 | 9,980 | [商品页](https://www.lcsc.com/product-detail/C51223760.html) |
| D3、D4 | SMF5.0A | C151296 | 2 | 19,465 | [商品页](https://www.lcsc.com/product-detail/C151296.html) |
| U1–U36 | SC4102DN-TR | C42408042 | 36 | 935 | [商品页](https://www.lcsc.com/product-detail/C42408042.html) |
| U37 | 74HC4067BQ,118 | C547033 | 1 | 99 | [商品页](https://www.lcsc.com/product-detail/C547033.html) |
| U40 | CH32X035G8U6 | C7437027 | 1 | 9,705 | [商品页](https://www.lcsc.com/product-detail/C7437027.html) |
| U41 | XC6210B332MR-G | C47719 | 1 | 13,331 | [商品页](https://www.lcsc.com/product-detail/C47719.html) |
| U42 | LP5308B6F | C5139783 | 1 | 29,385 | [商品页](https://www.lcsc.com/product-detail/C5139783.html) |

## 本次订单选料变化

1. R1、R12–R15：PS02W8F1003TCE / C2784785，100 kΩ、±1%、0402、125 mW、50 V，替换缺货的 0402WGF1003TCE。
2. R2：RC0402FR-0733RL / C138002，33 Ω、±1%、0402、62.5 mW、50 V，替换当前即时库存为 0 的 C25105。
3. U1–U36：用户确认采用 SC4102DN-TR / C42408042。与 SC410X 系列当前 DFN1616 封装和引脚配置匹配。在 3.3 V 下典型灵敏度为 1.5 mV/G，而 SC4103 为 2.5 mV/G；同磁场下信号幅度约为后者的 60%。必须重新校准键程、触发阈值、释放阈值和测速，并实测信噪比与全行程，不能仅换 BOM 后沿用旧参数。商城灵敏度字段可能采用不同供电条件，工程依据以原厂手册为准。
4. U41：采用 XC6210B332MR-G / C47719，兼容原型号的 -G 环保后缀，保持 B 型 CE 逻辑。
5. D1：订单选用 ElecSuper PESD3V3C2UM(ES) / C51223760，替换无法匹配立创货号的 SYT13S03SMD。已查阅厂家 Rev-1.2 手册：1/2=IO、3=GND；DFN1006-3L，IO 端子中心距 0.35 mm；3.3 V 工作、典型 0.51 pF、最大 0.60 pF、12 A 的 8/20 μs 脉冲下最大钳位 5 V。端子尺寸与当前焊盘有覆盖，可在现有焊盘上装配；厂家推荐焊盘不同，不声称两者推荐 land pattern 完全相同。原器件约 0.42 pF、TLP/触发曲线与新器件不同，需样板验证 USB 枚举、数据传输及 ESD。必须按实际器件 1 脚/底视图复核旋转，不能照搬相似型号的自动角度。

D1 新器件数据手册：https://datasheet.lcsc.com/datasheet/pdf/3f770d8afbe2808a8f8a2582526fece5.pdf?productCode=C51223760 。
霍尔原厂资料：https://www.semiment.com/UploadFiles/6720/SC4101_SC4102_SC4103_SC4104_CN.pdf 。
XC6210 原厂资料：https://product.torexsemi.com/system/files/series/xc6210.pdf 。
R2 原厂规格：https://www.yageogroup.com/component-documentation/download/specsheet/RC0402FR-0733RL 。

## 导入与装配

商城用采购版上传 BOM 智能云表，优先按商品编号精确匹配。SMT 用 SMT 版匹配位号、封装、数量和物料编号；按当前 BOM 筛选同版 CPL，仅保留 103 个采购位号，排除 C20、J2、TP1–TP8。当前交付不含新生成或校验过的 CPL，不能仅凭 CSV 直接投产。

原项目私有封装名称保留在 SMT CSV，反映实际 PCB 焊盘。平台可能要求人工映射自定义封装；不要按名称模糊匹配为相似外壳。检查 U37 的 DHVQFN24，禁止换成 TSSOP；检查 36 颗霍尔和 U40 的 1 脚及裸焊盘。对 D1 当前 0.15 mm 焊盘间距等原设计制造条件，仍按最新审阅记录与工厂确认。

当前文件用于选料与订单准备，不是新的投板放行，也不表示已上传、付款、锁库或提交生产。
