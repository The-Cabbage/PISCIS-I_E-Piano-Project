import concurrent.futures
import datetime
import json
import pathlib
import re
import sys
import urllib.request

OUT = pathlib.Path(__file__).resolve().parent
CODES = ['C1525','C52923','C77083','C368809','C2784785','C25105','C25118','C25744','C25798','C51223760','C151296','C42408042','C547033','C7437027','C47719','C5139783']
if len(sys.argv) > 1:
    CODES = sys.argv[1:]

def fetch(code):
    url = f'https://www.lcsc.com/product-detail/{code}.html'
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        html = urllib.request.urlopen(req, timeout=25).read().decode()
        data = json.loads(re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html).group(1))
        p = data['props']['pageProps']['webData']
        if p['productCode'] != code:
            raise ValueError(f'Wrong product: {p.get("productCode")}')
        keys = ['productCode','productModel','brandNameEn','encapStandard','stockNumber','stockSz','domesticStockVO','overseasStockVO','minBuyNumber','minPacketNumber','split','pdfUrl','productKeyAttributes','productNameEn']
        return dict(source_url=url, retrieved_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), **{k:p.get(k) for k in keys})
    except Exception as exc:
        return dict(productCode=code, source_url=url, error=str(exc))

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    rows = list(pool.map(fetch, CODES))
path = OUT / 'inventory-source.json'
previous = json.loads(path.read_text()) if path.exists() else []
merged = {r['productCode']: r for r in previous + rows}
path.write_text(json.dumps(list(merged.values()), ensure_ascii=False, indent=2))
for row in rows:
    print(row['productCode'], row.get('productModel'), row.get('stockNumber'), row.get('domesticStockVO'), row.get('error',''))
