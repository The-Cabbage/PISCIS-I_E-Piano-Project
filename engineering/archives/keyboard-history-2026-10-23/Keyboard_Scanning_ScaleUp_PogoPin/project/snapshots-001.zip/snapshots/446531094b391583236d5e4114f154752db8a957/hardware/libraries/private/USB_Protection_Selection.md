# USB protection component selection

## Recommended protection chain

```text
USB-C VBUS ──┬── SMF5.0A ── GND
             │
             └── LP5308B6F ── protected 5V_USB rail

USB-C CC1 ───── PESD5V0S2BT pin 1
USB-C CC2 ───── PESD5V0S2BT pin 2
GND       ───── PESD5V0S2BT pin 3

USB D+/D- ───── existing SYT13S03SMD / SY205253SMD
```

The low-cost LP5308B6F replaces the previously considered TI eFuse. The three selected parts are in the project-private KiCad library with project-local footprints and STEP models.

## Selected parts

| Function | Part | LCSC | Package | Key reason |
|---|---|---|---|---|
| CC1/CC2 ESD | Nexperia PESD5V0S2BT,215 | C49338 | SOT-23 | Two bidirectional 5 V lines, 30 kV IEC contact ESD; adequate for CC lines |
| VBUS TVS | Littelfuse SMF5.0A | C151296 | SOD-123FL | 5 V stand-off, 200 W pulse rating and 30 kV IEC contact ESD |
| VBUS sustained OVP/OCP | LowPowerSemi LP5308B6F | C5139783 | SOT-23-6 | 3 V to 36 V input, 5.85 V OVP, 0.2 A to 2.5 A adjustable OCP, UVLO/OTP/output discharge |

## LP5308B6F connection

| Pin | Name | Connection |
|---:|---|---|
| 1 | ENB | Active low. Tie to GND for deterministic always-on operation, or drive high to disable. The part has an internal pull-down and may also be left floating. |
| 2 | GND | Short, low-impedance connection to ground. |
| 3 | VIN | Connector-side VBUS, after the TVS branch point. Place a 1 uF ceramic capacitor from VIN to GND close to the pin. |
| 4 | VOUT | Protected `5V_USB`. Place a 1 uF ceramic capacitor from VOUT to GND close to the pin. |
| 5 | NC | No connection; do not use as a routing tie point. |
| 6 | ISET | Connect a 1% resistor to GND to set the over-current threshold. |

The datasheet relationship is approximately `RSET(kOhm) = 25 / IOCP(A)`. Practical starting values are 33.2 kOhm for about 0.75 A or 24.9 kOhm for about 1.0 A. Confirm the limit after measuring the keyboard's worst-case start-up and operating current; the device's OCP accuracy is approximately +/-15% above 150 mA. Do not use the protection switch as a substitute for USB current-advertisement or power-negotiation compliance.

## Placement and layout rules

1. Place SMF5.0A immediately behind the USB-C connector. Route connector VBUS to the TVS branch first and use the shortest possible return to a solid ground plane with nearby ground vias.
2. Place LP5308B6F after the TVS, before any VBUS bulk capacitor and before the `5V_USB` rail fans out. Keep raw connector VBUS and protected `5V_USB` as different nets.
3. SMF5.0A alone is not sufficient protection for the existing XC6210 LDO: its maximum TVS clamp is about 9.2 V, while the XC6210 absolute maximum input is 6.5 V. The LP5308B6F is what disconnects sustained over-voltage.
4. Place PESD5V0S2BT beside the connector. Keep CC1/CC2 stubs short and route its ground pin directly to the ground plane.
5. Retain the existing low-capacitance SYT13S03SMD/SY205253SMD on USB D+/D-; do not replace it with the higher-capacitance CC protector.

## Library assets

- Symbols: `Keyboard_Private.kicad_sym`
- Footprints: `Keyboard_Private.pretty/SOT-23.kicad_mod`, `D_SOD-123F.kicad_mod`, `SOT-23-6.kicad_mod`
- STEP models: `Keyboard_Private.3dshapes/SOT-23.step`, `D_SOD-123F.step`, `SOT-23-6.step`
- Raw source records: `sources/easyeda/C49338.json`, `C151296.json`, `C5139783.json`

Source references:

- Nexperia PESD5V0S2BT datasheet: https://assets.nexperia.com/documents/data-sheet/PESD5V0S2BT.pdf
- Littelfuse SMF series datasheet: https://www.littelfuse.com/assetdocs/littelfuse-tvs-diode-smf-datasheet
- LowPowerSemi LP5308 datasheet mirror: https://uploadcdn.oneyac.com/attachments/files/brand_pdf/lowpower/7E/CF/LP5308B6F.pdf
- LCSC LP5308B6F product page: https://www.lcsc.com/product-detail/Power-Distribution-Switches_LOWPOWER-LP5308B6F_C5139783.html
- Torex XC6210 datasheet: https://product.torexsemi.com/system/files/series/xc6210.pdf
