# PISCIS-I Keyboard

KiCad 10 project: `PISCIS-I_Keyboard.kicad_pro`.

Private library `Keyboard_Private` includes:

- `STM32G0B1CBT6` — LQFP-48 7x7 mm, LCSC C2847904.
- `SC4702SO-N-TR` — SOT-23-3, pins 1=VDD, 2=OUT, 3=GND, LCSC C52993621.
- `74HC4067PW,118` — Nexperia SOT355-1 / TSSOP-24, LCSC C179326.

Each footprint points to a project-local STEP model under `hardware/libraries/private/Keyboard_Private.3dshapes`. Symbols and footprints were checked against manufacturer data; raw EasyEDA official-library records are retained under `sources/easyeda`. STM32 and package assets are derived from the KiCad 10 official library snapshot.

- `CH32X035G8U6` — WCH QFN28 4x4 mm P0.4 mm, exposed pad 2.7x2.7 mm, LCSC C7437027. The footprint is the exact KiCad land pattern. The project-local STEP uses the matching 4x4 mm / 28-pin / 0.4 mm generic QFN body; its underside EP is 2.4 mm rather than 2.7 mm, which does not affect enclosure clearance but must not be used to derive the PCB land pattern.

- `XC6210B332MR` — Torex 700 mA fixed 3.3 V LDO, SOT-25; copied from the HPM6360 project private library with its `SOT-23-5` footprint and project-local STEP model.


## C2765186 private-library import

- Symbol: `Keyboard_Private:TYPE-C16PIN2MD-073`
- Footprint: `Keyboard_Private:USB-C-SMD_TYPE-C-16PIN-2MD-073`
- 3D model: `hardware/libraries/private/Keyboard_Private.3dshapes/TYPE-C-16PIN-2MD-073.step`
- Source: 嘉立创EDA/EasyEDA official library record C2765186 (https://easyeda.com/component/04b7d8073e854006b41709a96b7a21a9). Original source data is retained under `hardware/libraries/private/sources/easyeda/C2765186.json`.
- Note: EasyEDA labels the attached 3D asset `USB-C-SMD_TYPE-C-6PIN-2MD-073`; it is the model referenced by the official C2765186 package record and has been renamed locally for clarity.


## SYT13S03SMD private-library copy

- Symbol: `Keyboard_Private:SYT13S03SMD`
- Footprint: `Keyboard_Private:Silergy_DFN-3_1.0x0.6mm_SYT13S03SMD`
- Source: copied from the HPM6360 project private library. The current Silergy part number is `SY205253SMD`.
- This source footprint does not reference a 3D model, so no model file was copied.


## USB protection private-library additions

- `PESD5V0S2BT,215` (LCSC C49338) — Nexperia dual-line bidirectional protector for USB Type-C CC1/CC2. Uses the project-local `SOT-23` footprint and STEP model.
- `SMF5.0A` (LCSC C151296) — Littelfuse 5 V unidirectional TVS for connector-side VBUS transient suppression. Uses the project-local `D_SOD-123F` footprint and STEP model.
- `LP5308B6F` (LCSC C5139783) — LowPowerSemi/微源半导体 3 V to 36 V VBUS protection switch with 5.85 V OVP and resistor-programmable OCP. Uses the project-local `SOT-23-6` footprint and STEP model.
- Raw EasyEDA official-library records are retained under `hardware/libraries/private/sources/easyeda` for pin/package traceability.
- Selection, connection and layout notes: `hardware/libraries/private/USB_Protection_Selection.md`.


## 74HC4067BQ alternate footprint

- Footprint: `Keyboard_Private:Nexperia_DHVQFN-24-1EP_3.5x5.5mm_P0.5mm_SOT815-1`
- Intended part: Nexperia `74HC4067BQ,118`, LCSC C547033, package SOT815-1 / DHVQFN24, 3.5 x 5.5 mm, 0.5 mm pitch.
- Land pattern follows the Nexperia SOT815-1 reflow recommendation, including a 4.0 x 2.0 mm center land and six segmented paste apertures.
- 3D model: `hardware/libraries/private/Keyboard_Private.3dshapes/DHVQFN24_3.5x5.5mm_SOT815-1.step`, from the 3D model referenced by the EasyEDA C547033 package record.
- Pad 25 is the center exposed pad. For 74HC4067BQ it must remain floating or connect to VCC; it must not connect to GND.
- The existing `74HC4067PW,118` symbol-to-TSSOP-24 footprint mapping has not been changed.
- Raw EasyEDA official-library record is retained as `hardware/libraries/private/sources/easyeda/C547033.json` for traceability.


## DM18007-16FBAP-A private-library import

- Symbol: `Keyboard_Private:DM18007-16FBAP-A`
- Footprint: `Keyboard_Private:USB_C_Receptacle_XMCONN_DM18007-16FBAP-A`
- 3D model: `hardware/libraries/private/Keyboard_Private.3dshapes/XMCONN_DM18007-16FBAP-A.step`
- Manufacturer: Guangdong Xiaomai Industrial Co., Ltd. / XMCONN (广东小迈实业有限公司); manufacturer code `X2235`.
- Official product page: https://www.xmconn.com/typec16p/1378.html
- Official drawing: https://www.xmconn.com/uploads/soft/260526/DM18007-16FBAP-A.pdf
- The footprint follows the manufacturer recommended PCB layout: 12 signal lands for the 16 contacts, four plated oval shell stakes, and two 0.50 mm locating holes. The mid-mount PCB edge/cutout is shown on `Dwgs.User` and labelled on `Cmts.User`; copy/convert it to the board `Edge.Cuts` only after positioning the connector on the final board outline.
- The STEP file is the exact manufacturer-supplied `DM18007-16FBAP-A.stp`, not a similar USB-C substitute. Its KiCad orientation and offset place the contact tails on the PCB surface and the connector body through the documented mid-mount cutout.
- The official PDF, original STEP ZIP and captured product page are retained under `hardware/libraries/private/sources/xmconn` for traceability.
- This import does not change the footprint mapping of the connector already used by the schematic.
