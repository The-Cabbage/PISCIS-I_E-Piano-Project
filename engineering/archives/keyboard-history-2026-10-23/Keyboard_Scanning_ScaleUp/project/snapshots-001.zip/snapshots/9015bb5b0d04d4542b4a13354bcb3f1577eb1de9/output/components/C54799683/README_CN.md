# YZ126715035T-03025-01 / C54799683

来源：**嘉立创EDA/EasyEDA官方库 / JLCEDA/EasyEDA Official Library**，https://lceda.cn/ 和 https://easyeda.com/。
商品：https://www.lcsc.com/product-detail/C54799683.html
原厂图纸：https://datasheet.lcsc.com/datasheet/pdf/62f1f704272dcf9ca3a32dad9289ee29.pdf?productCode=C54799683，A.0，2025-04-03。
原始库数据：`../../easyeda/C54799683.json`。

- 符号：`Keyboard_Private:YZ126715035T-03025-01`，参考标号 J，3 个 passive 引脚。
- 封装：`Keyboard_Private:PogoPin_Xinyangze_YZ126715035T-03025-01_1x03_P2.50mm_SideMount`，三触点侧贴母座；固定凹面接触铜柱，不是弹性公针。
- 官方共享库名称：`CONN-SMD_3P-P2.50_YZ126715035T-03025F`；符号 UUID 94ea80d2f6c04fa4834be49123daef36；封装 UUID e14dd48953a8401e8780476baf5eec16。
- KiCad 10.0.6 原生导入。下载源的焊盘为 1.6 × 2.5 mm，按当前 -01 原厂图纸修正为 **1.6 × 2.3 mm**；其他几何图形保留。
- 焊盘 1/2/3 坐标 X=-2.4999/0/+2.4999 mm，Y=0，名义针距 2.5 mm。
- 定位孔：X=±1.2499 mm，Y=-0.35 mm，NPTH Ø0.7 mm。源数据微小舍入保留。
- 本体宽 7.8 mm、深 3.0 mm，轴向总长 3.5 mm。触点外径 Ø1.5 mm，凹面接触结构。
- 源编号按未旋转 KiCad 顶视图从左到右为 1/2/3；电气用途由设计定义。两板对接时按面对面的实际几何核对镜像编号。
- 与已导入 YZ10515055F-03025-01 公座的三触点、2.5 mm 针距、7.8 mm 宽度相对应。此判断来自各自图纸的几何比对；未取得原厂明确的配套认证声明。
- 两者沿同一 PCB 表面安装时，公座轴线距安装面 1.3 mm，母座为 1.2 mm，机械设计应考虑 0.1 mm 差值与安装公差，按公座 4.2 mm 工作长度设置压缩量，并以样品确认。
- 本体不包含磁铁，磁吸与导向结构需另外设计。
- 配套 STEP 来自官方关联模型，UUID 93ef72bb883f4d8ab3657385b71e0aee。模型保留原生导入位置参数，仅供参考；安装和外壳配合以图纸为准。
- 仅追加元件库；不放置或替换现有原理图/PCB 器件。


已追加到当前项目 Keyboard_Private 库；搜索型号即可。ZIP 内独立符号库只含此元件，不能覆盖当前项目包含其他器件的同名符号库。符号/封装已通过 KiCad 原生读取与导出检查。
